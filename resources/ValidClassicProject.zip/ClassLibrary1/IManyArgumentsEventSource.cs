﻿using System.Diagnostics.Tracing;
using ChilliCream.Tracing.Abstractions;

namespace ManyArgumentsEventSourceNamespace
{
    [EventSourceDefinition(Name = "ManyArgumentsEventSource")]
    public interface IManyArgumentsEventSource
    {
        [Event(1,
            Level = EventLevel.Informational,
            Message = "Simple is called {0}.",
            Version = 1)]
        void Simple(string a, short b, int c, long d, ushort e,
            uint f, ulong g, decimal h, System.Boolean i, bool j, double k);
    }
}
